import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-AddDoctor',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './AddDoctor.component.html',
  styleUrl: './AddDoctor.component.scss',
})
export class AddDoctorComponent {
}
